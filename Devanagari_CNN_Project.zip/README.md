# Devanagari Character Classification using CNN

This project uses a Convolutional Neural Network (CNN) to classify handwritten Hindi characters from the Devanagari dataset.

## Dataset
[Devanagari Handwritten Character Dataset](https://www.kaggle.com/datasets/berlinsweird/devanagari)

## Setup
1. Download and extract the dataset into a `dataset/` folder.
2. Ensure the folder has `train/` and `test/` subfolders with class-wise directories.
3. Run the notebook.

## Dependencies
- TensorFlow
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
